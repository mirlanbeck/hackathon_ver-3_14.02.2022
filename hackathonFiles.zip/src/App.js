import React from 'react';
import MyRoutes from './MyRoutes';

const App = () => {
  return (
    <div>
      <MyRoutes />
    </div>
  );
};

export default App;